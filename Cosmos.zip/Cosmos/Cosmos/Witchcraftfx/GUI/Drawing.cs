﻿using System;
using CMouse = Cosmos.System.MouseManager;
using Cosmos.System;
using Cosmos.System.Graphics;
using System.Drawing;

namespace WitchcraftOS.Witchcraftfx.GUI
{
    public static class Drawing
    {
        public static uint X = 10;
        public static uint Y = 10;
        public static uint oldX = 10;
        public static uint oldY = 10;
        public static void FillRectangle(uint __x, uint __y, uint __width, uint __height, Color __cindex)
        {
            for (uint y = __y; y != __height; y++)
            {
                for (uint x = __x; x != __width; x++)
                {
                    Screen.screen.DrawPoint(new Pen(__cindex), x, y);
                }
            }
        }
        public static void DrawRectangle(uint __x, uint __y, uint __width, uint __height, Color __cindex)
        {
            for (uint x = __x; x != __width; x++)
            {
                Screen.screen.DrawPoint(new Pen(__cindex), x, __y);
                Screen.screen.DrawPoint(new Pen(__cindex), x, __y + __height);
            }
            for (uint y = __y; y != __height; y++)
            {
                Screen.screen.DrawPoint(new Pen(__cindex), __x, y);
                Screen.screen.DrawPoint(new Pen(__cindex), __x + __width, y);
            }
        }
        public static void drawLine(uint x, uint y, uint length, Color color, bool vertical)
        {
            if (vertical)
            {
                //Is vertical
                for (uint l = 0; l <= length; l++)
                {
                    Screen.screen.DrawPoint(new Pen(color), x, y + 1);
                }
            }
            else
            {
                //Is NOT vertical
                for (uint l = 0; l <= length; l++)
                {
                    Screen.screen.DrawPoint(new Pen(color), x + 1, y);
                }

            }


        }
        public static void drawCircle(int x0, int y0, int radius, Color color)
        {
            int f = 1 - radius;
            int ddF_x = 1;
            int ddF_y = -2 * radius;
            int x = 0;
            int y = radius;

            Screen.screen.DrawPoint(new Pen(color), (uint)x0, (uint)(y0 + radius));
            Screen.screen.DrawPoint(new Pen(color), (uint)x0, (uint)(y0 - radius));
            Screen.screen.DrawPoint(new Pen(color), (uint)(x0 + radius), (uint)y0);
            Screen.screen.DrawPoint(new Pen(color), (uint)(x0 - radius), (uint)y0);

            while (x < y)
            {
                // ddF_x == 2 * x + 1;
                // ddF_y == -2 * y;
                // f == x*x + y*y - radius*radius + 2*x - y + 1;
                if (f >= 0)
                {
                    y--;
                    ddF_y += 2;
                    f += ddF_y;
                }
                x++;
                ddF_x += 2;
                f += ddF_x;
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 + x), (uint)(y0 + y));
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 - x), (uint)(y0 + y));
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 + x), (uint)(y0 - y));
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 - x), (uint)(y0 - y));
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 + y), (uint)(y0 + x));
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 - y), (uint)(y0 + x));
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 + y), (uint)(y0 - x));
                Screen.screen.DrawPoint(new Pen(color), (uint)(x0 - y), (uint)(y0 - x));
            }
        }
            public static void Update()
            {
                X = CMouse.X;
                Y = CMouse.Y;
                if (oldX != X || oldY != Y) UnDraw();
                Draw();
            }
            public static void Draw()
            {
                Screen.screen.DrawPoint(new Pen(Color.Black), X, Y);

                Screen.screen.DrawPoint(new Pen(Color.Black), X + 1, Y);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 2, Y);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 3, Y);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 4, Y);

                Screen.screen.DrawPoint(new Pen(Color.Black), X, Y + 1);
                Screen.screen.DrawPoint(new Pen(Color.Black), X, Y + 2);
                Screen.screen.DrawPoint(new Pen(Color.Black), X, Y + 3);
                Screen.screen.DrawPoint(new Pen(Color.Black), X, Y + 4);

                Screen.screen.DrawPoint(new Pen(Color.Black), X + 1, Y + 2);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 2, Y + 1);

                Screen.screen.DrawPoint(new Pen(Color.Black), X + 1, Y + 1);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 2, Y + 2);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 3, Y + 3);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 4, Y + 4);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 5, Y + 5);
                Screen.screen.DrawPoint(new Pen(Color.Black), X + 6, Y + 6);

                oldX = X;
                oldY = Y;
            }
            public static void UnDraw()
            {
                Screen.screen.DrawPoint(new Pen(Color.White), oldX, oldY);

                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 1, oldY);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 2, oldY);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 3, oldY);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 4, oldY);

                Screen.screen.DrawPoint(new Pen(Color.White), oldX, oldY + 1);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX, oldY + 2);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX, oldY + 3);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX, oldY + 4);

                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 1, oldY + 2);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 2, oldY + 1);

                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 1, oldY + 1);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 2, oldY + 2);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 3, oldY + 3);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 4, oldY + 4);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 5, oldY + 5);
                Screen.screen.DrawPoint(new Pen(Color.White), oldX + 6, oldY + 6);
            }
        }
    public static class useclass
    {
        public static void use<T>(this T thizz, Action<T> act)
        {
            act(thizz);
        }
    }
}