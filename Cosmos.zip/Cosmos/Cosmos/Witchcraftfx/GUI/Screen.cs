﻿using System;
using mouse = Cosmos.System.MouseManager;
using Cosmos.System.Graphics;
using System.Drawing;
namespace WitchcraftOS.Witchcraftfx.GUI
{
    public static class Screen
    {
        public enum colors : uint { black, white, red, green, blue, purple }
        public static Canvas screen;
        public static void Initialize()
        {
            screen = FullScreenCanvas.GetFullScreenCanvas();
            screen.Clear(Color.White);
            Font.SetupFont();
            Update();
        }
        public static void Update()
        {
            screen.Clear(Color.White);
            while (true)
            {
                Font.drawText("witchcraft desktop v" + Core.MainLoop.KernelVersion.ToString(), 4, 4, Color.Black, screen);
                Drawing.drawCircle(0, 0, 40, Color.Black);
            }
        }
    }
}
