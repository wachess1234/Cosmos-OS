﻿using System;
using System.Collections.Generic;

namespace WitchcraftOS.Witchcraftfx.Filesystem
{
    public class FAT
    {
        public FAT()
        {
        }
    }
}
